"""
Multi-City Real-Time Weather Forecast Dashboard
Streamlit UI for Delhi · Chennai · Mumbai UV/MV LSTM-GRU forecasting pipeline.
"""

import json
import warnings
import subprocess
import os
import shutil
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st

warnings.filterwarnings("ignore")

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="India Weather Forecast",
    page_icon="🌦️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Theme / CSS ───────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=DM+Sans:wght@300;400;500;600&display=swap');
html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }
.stApp { background: #0b0f1a; color: #e2e8f0; }
[data-testid="stSidebar"] { background: #111827; border-right: 1px solid #1e293b; }
[data-testid="stSidebar"] * { color: #cbd5e1 !important; }
.metric-card {
    background: linear-gradient(135deg, #1e293b 0%, #162032 100%);
    border: 1px solid #2d3f5e; border-radius: 12px;
    padding: 20px 24px; text-align: center;
    position: relative; overflow: hidden;
}
.metric-card::before {
    content: ''; position: absolute; top: 0; left: 0; right: 0;
    height: 3px; background: var(--accent);
}
.metric-value {
    font-family: 'Space Mono', monospace; font-size: 2rem;
    font-weight: 700; color: #f1f5f9; line-height: 1.1;
}
.metric-label { font-size: 0.72rem; letter-spacing: 0.12em; text-transform: uppercase; color: #64748b; margin-top: 4px; }
.metric-unit  { font-size: 0.85rem; color: #94a3b8; font-family: 'Space Mono', monospace; }
.section-title {
    font-family: 'Space Mono', monospace; font-size: 0.7rem;
    letter-spacing: 0.2em; text-transform: uppercase; color: #475569;
    margin-bottom: 16px; padding-bottom: 8px; border-bottom: 1px solid #1e293b;
}
.badge { display: inline-block; padding: 2px 10px; border-radius: 20px; font-size: 0.7rem; letter-spacing: 0.08em; font-weight: 600; text-transform: uppercase; }
.badge-green  { background: #052e16; color: #4ade80; border: 1px solid #166534; }
.badge-yellow { background: #1c1000; color: #facc15; border: 1px solid #713f12; }
.badge-blue   { background: #0c1a2e; color: #60a5fa; border: 1px solid #1e3a5f; }
.badge-red    { background: #1f0606; color: #f87171; border: 1px solid #7f1d1d; }
.info-box { background: #0c1a2e; border-left: 3px solid #3b82f6; border-radius: 0 8px 8px 0; padding: 12px 16px; font-size: 0.84rem; color: #94a3b8; margin: 8px 0 16px 0; }
hr { border-color: #1e293b; }
</style>
""", unsafe_allow_html=True)

# ── Constants ──────────────────────────────────────────────────────────────────
TARGETS    = ["PRmsl", "RH2m", "TMP2m"]
UNITS      = {"PRmsl": "Pa", "RH2m": "%", "TMP2m": "°C"}
COLORS     = {"PRmsl": "#3b82f6", "RH2m": "#10b981", "TMP2m": "#f59e0b"}
FULL_NAMES = {
    "PRmsl": "Mean Sea-Level Pressure",
    "RH2m" : "Relative Humidity",
    "TMP2m": "Temperature",
}
CITIES = {
    "Mumbai" : {"lat": 19.11,   "lon": 72.85,  "flag": "🇮🇳", "subdir": "mumbai"},
    "Delhi"  : {"lat": 28.6139, "lon": 77.2090, "flag": "🇮🇳", "subdir": "delhi"},
    "Chennai": {"lat": 13.0700, "lon": 80.2500, "flag": "🇮🇳", "subdir": "chennai"},
}

MODEL_LABELS = {
    ("uv", "A"): "Univariate — Hybrid LSTM-GRU",
    ("uv", "B"): "Univariate — GRU + Attention",
    ("mv", "A"): "Multivariate — Hybrid LSTM-GRU",
    ("mv", "B"): "Multivariate — GRU + Attention",
}

# ── Paths ──────────────────────────────────────────────────────────────────────
DATA_DIR = Path("data")

def city_data_paths(city_name):
    c = city_name.lower()
    return {
        "forecast_log" : DATA_DIR / "logs" / f"forecast_log_{c}.jsonl",
        "adjust_log"   : DATA_DIR / "logs" / f"weight_adjustment_log_{c}.json",
        "nasa_cache"   : DATA_DIR / "cache" / f"nasa_cache_{c}.csv",
    }

ACCURACY_METRICS = DATA_DIR / "accuracy_metrics.json"

# ── Auto-fetch from Kaggle (silent, per-city) ──────────────────────────────────
def fetch_kaggle_data_for_city(city_name):
    """Download latest NASA cache and logs for one city from Kaggle (silent fail)."""
    try:
        paths = city_data_paths(city_name)
        cache_file = paths["nasa_cache"]
        if cache_file.exists():
            age_hours = (datetime.now() - datetime.fromtimestamp(
                cache_file.stat().st_mtime)).total_seconds() / 3600
            if age_hours < 12:
                return  # fresh enough

        DATA_DIR.mkdir(parents=True, exist_ok=True)
        (DATA_DIR / "logs").mkdir(parents=True, exist_ok=True)
        (DATA_DIR / "cache").mkdir(parents=True, exist_ok=True)
        output_tmp = DATA_DIR / f"tmp_{city_name.lower()}"
        output_tmp.mkdir(exist_ok=True)

        result = subprocess.run(
            ["kaggle", "datasets", "download",
             "-d", f"souravkumar0403/cache-{city_name.lower()}",
             "-p", str(output_tmp), "--unzip"],
            capture_output=True, timeout=60
        )
        if result.returncode == 0:
            c = city_name.lower()
            for fname, dst in [
                (f"nasa_cache_{c}.csv",             paths["nasa_cache"]),
                (f"forecast_log_{c}.jsonl",         paths["forecast_log"]),
                (f"weight_adjustment_log_{c}.json", paths["adjust_log"]),
            ]:
                src = output_tmp / fname
                if src.exists():
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(str(src), str(dst))
            # accuracy_metrics.json (city-agnostic)
            am_src = output_tmp / "accuracy_metrics.json"
            if am_src.exists():
                shutil.copy2(str(am_src), str(ACCURACY_METRICS))
        shutil.rmtree(output_tmp, ignore_errors=True)
    except Exception:
        pass  # Silent fail — use existing data if download fails


# Auto-fetch on startup for all cities
for _city in CITIES:
    fetch_kaggle_data_for_city(_city)

# ── Data loaders ──────────────────────────────────────────────────────────────
@st.cache_data(ttl=300)
def load_forecast_log(city_name) -> pd.DataFrame:
    path = city_data_paths(city_name)["forecast_log"]
    if not path.exists():
        return pd.DataFrame()
    rows = []
    with open(path, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
                base = {
                    "forecast_date"     : entry.get("forecast_date"),
                    "nasa_latest"       : entry.get("nasa_latest"),
                    "run_timestamp"     : entry.get("run_timestamp"),
                    "adjustment_applied": entry.get("adjustment_applied", False),
                }
                for tgt in TARGETS:
                    fc = entry.get("forecasts", {}).get(tgt, {})
                    base[f"{tgt}_MV_A"]     = fc.get("MV_A")
                    base[f"{tgt}_MV_B"]     = fc.get("MV_B")
                    base[f"{tgt}_UV_A"]     = fc.get("UV_A")
                    base[f"{tgt}_UV_B"]     = fc.get("UV_B")
                    base[f"{tgt}_ensemble"] = fc.get("ensemble")
                rows.append(base)
            except (json.JSONDecodeError, KeyError):
                continue
    if not rows:
        return pd.DataFrame()
    df = pd.DataFrame(rows)
    df["forecast_date"] = pd.to_datetime(df["forecast_date"])
    return df.sort_values("forecast_date").drop_duplicates("forecast_date").reset_index(drop=True)


@st.cache_data(ttl=300)
def load_adjustment_log(city_name) -> list:
    path = city_data_paths(city_name)["adjust_log"]
    if not path.exists():
        return []
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return []


@st.cache_data(ttl=300)
def load_nasa_cache(city_name) -> pd.DataFrame:
    path = city_data_paths(city_name)["nasa_cache"]
    if not path.exists():
        return pd.DataFrame()
    df = pd.read_csv(path, encoding="utf-8", on_bad_lines="skip")
    df["date"] = pd.to_datetime(df["date"])
    return df.sort_values("date").reset_index(drop=True)


@st.cache_data(ttl=300)
def load_accuracy_metrics() -> dict:
    if not ACCURACY_METRICS.exists():
        return {}
    try:
        return json.loads(ACCURACY_METRICS.read_text(encoding="utf-8"))
    except Exception:
        return {}


def data_status(city_name) -> dict:
    paths = city_data_paths(city_name)
    return {
        "forecast_log": paths["forecast_log"].exists(),
        "adjust_log"  : paths["adjust_log"].exists(),
        "nasa_cache"  : paths["nasa_cache"].exists(),
    }

# ── Plot helpers ──────────────────────────────────────────────────────────────
PLOTLY_LAYOUT = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(11,15,26,0.6)",
    font=dict(color="#94a3b8", family="DM Sans"),
    xaxis=dict(gridcolor="#1e293b", linecolor="#1e293b", zerolinecolor="#1e293b"),
    yaxis=dict(gridcolor="#1e293b", linecolor="#1e293b", zerolinecolor="#1e293b"),
    legend=dict(bgcolor="rgba(0,0,0,0)", bordercolor="#1e293b", borderwidth=1),
    margin=dict(l=50, r=20, t=40, b=40),
)

def apply_layout(fig, title="", height=380):
    fig.update_layout(
        **PLOTLY_LAYOUT,
        title=dict(text=title, font=dict(size=13, color="#e2e8f0")),
        height=height,
    )
    return fig


# ══════════════════════════════════════════════════════════════════════════════
# SIDEBAR
# ══════════════════════════════════════════════════════════════════════════════
with st.sidebar:
    st.markdown("## 🌦️ Forecast Config")
    st.markdown("---")

    # City selector
    city = st.selectbox(
        "🌏 City", list(CITIES.keys()), index=0,
        help="Select a city. Each city has its own trained models."
    )
    lat, lon = CITIES[city]["lat"], CITIES[city]["lon"]
    st.caption(f"Lat {lat}°N · Lon {lon}°E · NASA POWER")
    st.markdown("---")

    # Feature mode
    st.markdown("**Feature Mode**")
    mode_label = st.radio(
        "", ["Univariate (UV)", "Multivariate (MV)"],
        help="UV: self-lags + seasonality.\nMV: cross-variable, wind, QV2m, physics, monsoon.",
    )
    mode = "uv" if mode_label.startswith("Uni") else "mv"

    # Model architecture
    st.markdown("**Model Architecture**")
    arch_label = st.radio("", ["Hybrid LSTM-GRU  (Model A)", "GRU + Attention  (Model B)"])
    arch = "A" if "Model A" in arch_label else "B"

    st.markdown("---")

    # Data status for selected city
    st.markdown(f"**Data Status — {city}**")
    status = data_status(city)
    icons = {True: "🟢", False: "🔴"}
    st.markdown(f"{icons[status['forecast_log']]} Forecast log")
    st.markdown(f"{icons[status['nasa_cache']]}  NASA cache")
    st.markdown(f"{icons[status['adjust_log']]} Adjustment log")
    st.markdown(f"{icons[ACCURACY_METRICS.exists()]} Accuracy metrics")

    st.markdown("---")
    if st.button("🔄 Refresh data", use_container_width=True):
        st.cache_data.clear()
        st.rerun()
    st.caption("Data refreshes every 5 min automatically.")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN CONTENT
# ══════════════════════════════════════════════════════════════════════════════
st.markdown(f"# 🌦️ {city} Real-Time Weather Forecast")
st.markdown(
    f"<p style='color:#475569;font-size:0.85rem;margin-top:-12px;'>"
    f"Model: <b style='color:#94a3b8'>{MODEL_LABELS[(mode, arch)]}</b> &nbsp;·&nbsp; "
    f"City: <b style='color:#94a3b8'>{city}</b></p>",
    unsafe_allow_html=True,
)

# Load data for selected city
df_log  = load_forecast_log(city)
adj_log = load_adjustment_log(city)
df_nasa = load_nasa_cache(city)
acc_met = load_accuracy_metrics()
no_data = df_log.empty

# ── Tabs ──────────────────────────────────────────────────────────────────────
tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
    "📡 Today's Forecast",
    "📈 Historical Predictions",
    "🎯 Forecast Accuracy",
    "⚙️ Weight Adjustments",
    "📊 Model Metrics",
    "🌡️ Climate Context",
])


# ══════════════════════════════════════════════════════════════════════════════
# TAB 1 — TODAY'S FORECAST
# ══════════════════════════════════════════════════════════════════════════════
with tab1:
    if no_data:
        st.info(f"No forecast data found for **{city}**. Place Kaggle output files in `data/` — see the Setup Guide below.")
    else:
        latest    = df_log.iloc[-1]
        fc_date   = latest["forecast_date"]
        model_key = f"{mode.upper()}_{arch}"

        col_hdr1, col_hdr2, col_hdr3 = st.columns([2, 1, 1])
        with col_hdr1:
            st.markdown(f"### Forecast for **{fc_date.strftime('%A, %d %b %Y')}**")
        with col_hdr2:
            adj   = "✅ Adjusted" if latest.get("adjustment_applied") else "⏳ Not yet"
            badge = "green" if latest.get("adjustment_applied") else "yellow"
            st.markdown(f"<br><span class='badge badge-{badge}'>{adj}</span>", unsafe_allow_html=True)
        with col_hdr3:
            st.markdown(f"<br><span class='badge badge-blue'>{model_key}</span>", unsafe_allow_html=True)

        st.markdown("---")

        # 3 metric cards
        accents = {"PRmsl": "#3b82f6", "RH2m": "#10b981", "TMP2m": "#f59e0b"}
        cols = st.columns(3)
        for col, tgt in zip(cols, TARGETS):
            val = latest.get(f"{tgt}_{model_key}")
            ens = latest.get(f"{tgt}_ensemble")
            with col:
                if val is not None:
                    st.markdown(f"""
                    <div class="metric-card" style="--accent:{accents[tgt]}">
                        <div class="metric-label">{FULL_NAMES[tgt]}</div>
                        <div class="metric-value">{val:.1f}<span class="metric-unit"> {UNITS[tgt]}</span></div>
                        <div style="margin-top:8px;font-size:0.75rem;color:#475569;">
                            Ensemble avg: <span style="color:#94a3b8">{ens:.1f} {UNITS[tgt]}</span>
                        </div>
                    </div>""", unsafe_allow_html=True)
                else:
                    st.markdown(f"""
                    <div class="metric-card" style="--accent:#334155">
                        <div class="metric-label">{FULL_NAMES[tgt]}</div>
                        <div class="metric-value" style="color:#475569">N/A</div>
                        <div style="margin-top:8px;font-size:0.75rem;color:#334155;">Model not loaded</div>
                    </div>""", unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)

        # All-4-model comparison
        st.markdown("<div class='section-title'>All Models Comparison</div>", unsafe_allow_html=True)
        model_keys = ["MV_A", "MV_B", "UV_A", "UV_B", "ensemble"]
        model_nice = {
            "MV_A": "MV — LSTM-GRU", "MV_B": "MV — GRU+Attn",
            "UV_A": "UV — LSTM-GRU", "UV_B": "UV — GRU+Attn",
            "ensemble": "⭐ Ensemble",
        }
        bar_colors = {
            "MV_A": "#3b82f6", "MV_B": "#60a5fa",
            "UV_A": "#8b5cf6", "UV_B": "#a78bfa",
            "ensemble": "#f59e0b",
        }
        fig = make_subplots(rows=1, cols=3,
                            subplot_titles=[f"{FULL_NAMES[t]} ({UNITS[t]})" for t in TARGETS])
        for col_idx, tgt in enumerate(TARGETS, 1):
            vals  = [latest.get(f"{tgt}_{mk}") for mk in model_keys]
            names = [model_nice[mk] for mk in model_keys]
            clrs  = [bar_colors[mk] for mk in model_keys]
            valid = [(n, v, c) for n, v, c in zip(names, vals, clrs) if v is not None]
            if valid:
                ns, vs, cs = zip(*valid)
                fig.add_trace(go.Bar(
                    x=list(ns), y=list(vs), marker_color=list(cs), opacity=0.85,
                    showlegend=False, text=[f"{v:.1f}" for v in vs],
                    textposition="outside", textfont=dict(size=10, color="#94a3b8"),
                ), row=1, col=col_idx)
        apply_layout(fig, height=320)
        fig.update_layout(showlegend=False)
        st.plotly_chart(fig, use_container_width=True)

        # 60-day context
        if not df_nasa.empty:
            st.markdown("<div class='section-title'>60-Day Context + Forecast</div>", unsafe_allow_html=True)
            ctx  = df_nasa.tail(60)
            fig2 = make_subplots(rows=3, cols=1, shared_xaxes=True,
                                  subplot_titles=[f"{FULL_NAMES[t]} ({UNITS[t]})" for t in TARGETS],
                                  vertical_spacing=0.08)
            for row, tgt in enumerate(TARGETS, 1):
                if tgt not in ctx.columns:
                    continue
                color = COLORS[tgt]
                fig2.add_trace(go.Scatter(
                    x=ctx["date"], y=ctx[tgt],
                    line=dict(color=color, width=1.8),
                    name=tgt, showlegend=False,
                ), row=row, col=1)
                v = latest.get(f"{tgt}_{model_key}")
                if v is not None:
                    fig2.add_trace(go.Scatter(
                        x=[fc_date], y=[v], mode="markers+text",
                        text=[f"  {v:.1f}"], textposition="middle right",
                        textfont=dict(color=color, size=11),
                        marker=dict(size=12, color=color, symbol="diamond",
                                    line=dict(color="white", width=1.5)),
                        name=f"{tgt} forecast", showlegend=False,
                    ), row=row, col=1)
                fig2.add_vline(x=ctx["date"].max(), line_dash="dot",
                               line_color="#334155", row=row, col=1)
            apply_layout(fig2, title="Observed history + 1-day forecast", height=600)
            st.plotly_chart(fig2, use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# TAB 2 — HISTORICAL PREDICTIONS
# ══════════════════════════════════════════════════════════════════════════════
with tab2:
    if no_data:
        st.info("No forecast data found.")
    else:
        st.markdown("<div class='section-title'>All Logged Forecasts vs Observed (where available)</div>",
                    unsafe_allow_html=True)
        model_key = f"{mode.upper()}_{arch}"
        min_date  = df_log["forecast_date"].min().date()
        max_date  = df_log["forecast_date"].max().date()
        col_d1, col_d2 = st.columns(2)
        with col_d1:
            d_from = st.date_input("From", value=min_date, min_value=min_date, max_value=max_date)
        with col_d2:
            d_to = st.date_input("To", value=max_date, min_value=min_date, max_value=max_date)

        mask   = (df_log["forecast_date"].dt.date >= d_from) & (df_log["forecast_date"].dt.date <= d_to)
        df_sub = df_log[mask].copy()

        if df_sub.empty:
            st.warning("No forecasts in this date range.")
        else:
            if not df_nasa.empty:
                df_obs = df_nasa[["date"] + [t for t in TARGETS if t in df_nasa.columns]].copy()
                df_obs = df_obs.rename(columns={t: f"{t}_actual" for t in TARGETS})
                df_sub = df_sub.merge(df_obs, left_on="forecast_date", right_on="date", how="left")

            for tgt in TARGETS:
                pred_col   = f"{tgt}_{model_key}"
                ens_col    = f"{tgt}_ensemble"
                actual_col = f"{tgt}_actual"
                fig = go.Figure()
                fig.add_trace(go.Scatter(
                    x=df_sub["forecast_date"], y=df_sub[pred_col],
                    name=f"{model_key} Forecast", line=dict(color=COLORS[tgt], width=2),
                    mode="lines+markers", marker=dict(size=5),
                ))
                fig.add_trace(go.Scatter(
                    x=df_sub["forecast_date"], y=df_sub[ens_col],
                    name="Ensemble", line=dict(color="#f1f5f9", width=1.5, dash="dot"),
                    mode="lines",
                ))
                if actual_col in df_sub.columns:
                    fig.add_trace(go.Scatter(
                        x=df_sub["forecast_date"], y=df_sub[actual_col],
                        name="Actual (NASA)", line=dict(color="#475569", width=2, dash="dash"),
                        mode="lines+markers", marker=dict(size=4, symbol="x"),
                    ))
                apply_layout(fig, title=f"{FULL_NAMES[tgt]} ({UNITS[tgt]}) — Predicted vs Actual", height=320)
                st.plotly_chart(fig, use_container_width=True)

        # Adjustment-flagged runs
        st.markdown("<div class='section-title'>Runs with Weight Adjustment</div>", unsafe_allow_html=True)
        adj_runs = df_log[df_log["adjustment_applied"] == True]
        if adj_runs.empty:
            st.caption("No adjusted runs yet.")
        else:
            st.dataframe(
                adj_runs[["forecast_date", "adjustment_applied"] +
                          [f"{t}_ensemble" for t in TARGETS]].tail(20),
                use_container_width=True, hide_index=True,
            )


# ══════════════════════════════════════════════════════════════════════════════
# TAB 3 — FORECAST ACCURACY (live, computed from log vs nasa)
# ══════════════════════════════════════════════════════════════════════════════
with tab3:
    if no_data or df_nasa.empty:
        st.info("Need both forecast_log and nasa_cache to compute live accuracy.")
    else:
        st.markdown("<div class='section-title'>Live Accuracy — Forecast Log vs NASA Observed</div>",
                    unsafe_allow_html=True)
        model_key = f"{mode.upper()}_{arch}"
        df_obs    = df_nasa[["date"] + [t for t in TARGETS if t in df_nasa.columns]].copy()
        df_obs    = df_obs.rename(columns={t: f"{t}_actual" for t in TARGETS})
        df_merged = df_log.merge(df_obs, left_on="forecast_date", right_on="date", how="inner")

        def metrics(pred, actual):
            mask = (~np.isnan(pred)) & (~np.isnan(actual))
            p, a = pred[mask], actual[mask]
            if len(p) < 2:
                return None
            rmse = float(np.sqrt(np.mean((p - a)**2)))
            mae  = float(np.mean(np.abs(p - a)))
            bias = float(np.mean(p - a))
            ss_res = np.sum((a - p)**2)
            ss_tot = np.sum((a - a.mean())**2)
            r2 = float(1 - ss_res / ss_tot) if ss_tot > 0 else float("nan")
            return dict(rmse=rmse, mae=mae, bias=bias, r2=r2, n=int(mask.sum()))

        rows_metrics = []
        for tgt in TARGETS:
            pred_col   = f"{tgt}_{model_key}"
            actual_col = f"{tgt}_actual"
            ens_col    = f"{tgt}_ensemble"
            if pred_col not in df_merged.columns or actual_col not in df_merged.columns:
                continue
            pred   = df_merged[pred_col].values.astype(float)
            actual = df_merged[actual_col].values.astype(float)
            ens    = df_merged[ens_col].values.astype(float)
            for model_lbl, arr in [(model_key, pred), ("Ensemble", ens)]:
                m = metrics(arr, actual)
                if m:
                    rows_metrics.append({
                        "Target": tgt, "Unit": UNITS[tgt], "Model": model_lbl,
                        "RMSE": round(m["rmse"], 4), "MAE": round(m["mae"], 4),
                        "Bias": round(m["bias"], 4), "R²": round(m["r2"], 4),
                        "N": m["n"],
                    })
        if rows_metrics:
            st.dataframe(pd.DataFrame(rows_metrics), use_container_width=True, hide_index=True)

        # Error over time
        st.markdown("<div class='section-title'>Absolute Error Over Time</div>", unsafe_allow_html=True)
        fig = make_subplots(rows=3, cols=1, shared_xaxes=True,
                            subplot_titles=[f"{FULL_NAMES[t]} |Error| ({UNITS[t]})" for t in TARGETS],
                            vertical_spacing=0.08)
        for row, tgt in enumerate(TARGETS, 1):
            pred_col   = f"{tgt}_{model_key}"
            actual_col = f"{tgt}_actual"
            if pred_col not in df_merged.columns or actual_col not in df_merged.columns:
                continue
            ae   = (df_merged[pred_col] - df_merged[actual_col]).abs()
            roll = ae.rolling(7, min_periods=1).mean()
            fig.add_trace(go.Bar(x=df_merged["forecast_date"], y=ae,
                                 marker_color=COLORS[tgt], opacity=0.35, showlegend=False), row=row, col=1)
            fig.add_trace(go.Scatter(x=df_merged["forecast_date"], y=roll,
                                     line=dict(color=COLORS[tgt], width=2), showlegend=False), row=row, col=1)
        apply_layout(fig, title="Daily |error| + 7-day rolling mean", height=560)
        st.plotly_chart(fig, use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# TAB 4 — WEIGHT ADJUSTMENTS
# ══════════════════════════════════════════════════════════════════════════════
with tab4:
    st.markdown(f"<div class='section-title'>Online Weight Adjustment History — {city} (MV_A)</div>",
                unsafe_allow_html=True)
    if not adj_log:
        st.info("No weight adjustment records yet. Adjustments run automatically when observed data is available.")
    else:
        total       = len(adj_log)
        total_tgt   = sum(len(rec.get("targets", {})) for rec in adj_log)
        improved    = sum(1 for rec in adj_log
                         for td in rec.get("targets", {}).values()
                         if td.get("improved", False))

        c1, c2, c3 = st.columns(3)
        with c1:
            st.markdown(f"""<div class="metric-card" style="--accent:#3b82f6">
                <div class="metric-label">Total Adjustment Runs</div>
                <div class="metric-value">{total}</div></div>""", unsafe_allow_html=True)
        with c2:
            pct = round(improved / total_tgt * 100) if total_tgt else 0
            st.markdown(f"""<div class="metric-card" style="--accent:#10b981">
                <div class="metric-label">Target Adj. Improved</div>
                <div class="metric-value">{pct}<span class="metric-unit">%</span></div></div>""",
                        unsafe_allow_html=True)
        with c3:
            st.markdown(f"""<div class="metric-card" style="--accent:#f59e0b">
                <div class="metric-label">Targets Adjusted</div>
                <div class="metric-value">{total_tgt}</div></div>""", unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown("<div class='section-title'>Per-run Detail</div>", unsafe_allow_html=True)

        rows_adj = []
        for rec in adj_log:
            run_date   = rec.get("date", "—")
            actual_day = rec.get("actual_day", "—")
            for tgt, td in rec.get("targets", {}).items():
                rows_adj.append({
                    "Run Date"   : run_date,
                    "Actual Day" : actual_day,
                    "Target"     : tgt,
                    "Actual"     : td.get("actual"),
                    "Orig Pred"  : td.get("orig_pred"),
                    "Tuned Pred" : td.get("tuned_pred"),
                    "Δ |Error|"  : round(
                        abs(td.get("actual", 0) - td.get("orig_pred", 0)) -
                        abs(td.get("actual", 0) - td.get("tuned_pred", 0)), 4
                    ) if all(td.get(k) is not None for k in ["actual","orig_pred","tuned_pred"]) else None,
                    "Improved"   : "✅" if td.get("improved") else "❌",
                    "Best LR"    : td.get("best_hp", {}).get("lr"),
                })

        if rows_adj:
            df_adj = pd.DataFrame(rows_adj)
            st.dataframe(df_adj, use_container_width=True, hide_index=True)

            # Error reduction chart
            st.markdown("<div class='section-title'>Error Reduction per Adjustment Run</div>",
                        unsafe_allow_html=True)
            fig = go.Figure()
            for tgt in TARGETS:
                sub = df_adj[df_adj["Target"] == tgt].dropna(subset=["Δ |Error|"])
                if sub.empty:
                    continue
                fig.add_trace(go.Bar(
                    x=sub["Actual Day"], y=sub["Δ |Error|"],
                    name=f"{tgt} Δ|err|",
                    marker_color=[COLORS[tgt] if v >= 0 else "#ef4444" for v in sub["Δ |Error|"]],
                    opacity=0.85,
                    text=[f"{v:+.3f}" for v in sub["Δ |Error|"]], textposition="outside",
                ))
            apply_layout(fig, title="Δ|Error| = |Before| − |After|  (positive = improved)", height=360)
            fig.add_hline(y=0, line_color="#475569", line_dash="dot")
            st.plotly_chart(fig, use_container_width=True)

            # Loss curves from last adjustment
            last_rec = adj_log[-1]
            st.markdown("<div class='section-title'>Fine-Tune Loss — Last Adjustment</div>",
                        unsafe_allow_html=True)
            fig2 = make_subplots(rows=1, cols=3,
                                  subplot_titles=[f"{t} ({UNITS[t]})" for t in TARGETS])
            for col_idx, tgt in enumerate(TARGETS, 1):
                lc = last_rec.get("targets", {}).get(tgt, {}).get("loss_curve", [])
                if lc:
                    fig2.add_trace(go.Scatter(
                        y=lc, x=list(range(1, len(lc) + 1)),
                        line=dict(color=COLORS[tgt], width=2.5),
                        mode="lines+markers", marker=dict(size=5), showlegend=False,
                    ), row=1, col=col_idx)
            apply_layout(fig2, title=f"Fine-tune loss — {last_rec.get('actual_day','?')}", height=280)
            st.plotly_chart(fig2, use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# TAB 5 — MODEL METRICS (from training accuracy_metrics.json)
# ══════════════════════════════════════════════════════════════════════════════
with tab5:
    st.markdown("<div class='section-title'>Training-Time Accuracy Metrics (from Kaggle output)</div>",
                unsafe_allow_html=True)

    if not acc_met:
        st.info("No `accuracy_metrics.json` found. This file is produced by the training notebook and fetched from Kaggle output.")
    else:
        city_metrics_all = acc_met.get("cities", {})
        if city not in city_metrics_all:
            st.warning(f"No accuracy data for **{city}** in accuracy_metrics.json.")
        else:
            city_m = city_metrics_all[city]
            st.caption(f"Generated at: {acc_met.get('generated_at', 'unknown')}")

            # Build table
            rows = []
            for mode_key, mode_lbl in [("univariate", "Univariate"), ("multivariate", "Multivariate")]:
                for tgt in TARGETS:
                    for model_letter in ["A", "B"]:
                        m = city_m.get(mode_key, {}).get(tgt, {}).get(model_letter, {})
                        for split in ["train", "val", "test"]:
                            sm = m.get(split, {})
                            if sm:
                                rows.append({
                                    "Mode"   : mode_lbl,
                                    "Target" : tgt,
                                    "Unit"   : UNITS[tgt],
                                    "Model"  : f"Model {model_letter}",
                                    "Split"  : split.capitalize(),
                                    "R²"     : sm.get("r2"),
                                    "RMSE"   : sm.get("rmse"),
                                    "MAE"    : sm.get("mae"),
                                    "Bias"   : sm.get("bias"),
                                    "MAPE%"  : sm.get("mape"),
                                    "Overfit Gap": m.get("overfit_gap") if split == "test" else None,
                                })
            if rows:
                df_acc = pd.DataFrame(rows)
                # Filter to test only by default, with toggle
                show_all = st.checkbox("Show Train / Val / Test (default: Test only)", value=False)
                if not show_all:
                    df_acc = df_acc[df_acc["Split"] == "Test"]
                st.dataframe(df_acc, use_container_width=True, hide_index=True)

                # R² bar chart for test set
                st.markdown("<div class='section-title'>Test R² Comparison — All Models</div>",
                            unsafe_allow_html=True)
                df_test = df_acc[df_acc["Split"] == "Test"].copy() if show_all else df_acc.copy()
                if not df_test.empty:
                    fig = make_subplots(rows=1, cols=3,
                                        subplot_titles=[f"{FULL_NAMES[t]} ({UNITS[t]})" for t in TARGETS])
                    bar_colors_acc = {
                        ("Univariate",   "Model A"): "#3b82f6",
                        ("Univariate",   "Model B"): "#60a5fa",
                        ("Multivariate", "Model A"): "#f59e0b",
                        ("Multivariate", "Model B"): "#fbbf24",
                    }
                    for col_idx, tgt in enumerate(TARGETS, 1):
                        sub = df_test[df_test["Target"] == tgt]
                        for _, row_r in sub.iterrows():
                            key = (row_r["Mode"], row_r["Model"])
                            fig.add_trace(go.Bar(
                                x=[f"{row_r['Mode'][:2]}-{row_r['Model'][-1]}"],
                                y=[row_r["R²"]],
                                marker_color=bar_colors_acc.get(key, "#64748b"),
                                opacity=0.85, showlegend=False,
                                text=[f"{row_r['R²']:.4f}"], textposition="outside",
                            ), row=1, col=col_idx)
                    apply_layout(fig, title=f"Test R² — {city}", height=320)
                    st.plotly_chart(fig, use_container_width=True)

            # All-city comparison
            if len(city_metrics_all) > 1:
                st.markdown("<div class='section-title'>All Cities — Test R² Snapshot (MV_A)</div>",
                            unsafe_allow_html=True)
                comp_rows = []
                for cname, cm in city_metrics_all.items():
                    for tgt in TARGETS:
                        r2 = cm.get("multivariate", {}).get(tgt, {}).get("A", {}).get("test", {}).get("r2")
                        comp_rows.append({"City": cname, "Target": tgt, "MV_A Test R²": r2})
                if comp_rows:
                    df_comp = pd.DataFrame(comp_rows).pivot(index="City", columns="Target", values="MV_A Test R²")
                    st.dataframe(df_comp.round(4), use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# TAB 6 — CLIMATE CONTEXT
# ══════════════════════════════════════════════════════════════════════════════
with tab6:
    if df_nasa.empty:
        st.info(f"NASA cache for {city} not found.")
    else:
        st.markdown(f"<div class='section-title'>Full Historical Record — {city} NASA POWER</div>",
                    unsafe_allow_html=True)
        yrs = sorted(df_nasa["date"].dt.year.unique())
        col_y1, col_y2 = st.columns(2)
        with col_y1:
            yr_from = st.selectbox("From year", yrs, index=0)
        with col_y2:
            yr_to = st.selectbox("To year", yrs, index=len(yrs) - 1)
        df_ctx = df_nasa[(df_nasa["date"].dt.year >= yr_from) & (df_nasa["date"].dt.year <= yr_to)]

        fig = make_subplots(rows=3, cols=1, shared_xaxes=True,
                            subplot_titles=[f"{FULL_NAMES[t]} ({UNITS[t]})" for t in TARGETS],
                            vertical_spacing=0.06)
        for row, tgt in enumerate(TARGETS, 1):
            if tgt not in df_ctx.columns:
                continue
            roll30 = df_ctx[tgt].rolling(30, min_periods=1).mean()
            fig.add_trace(go.Scatter(x=df_ctx["date"], y=df_ctx[tgt],
                                     line=dict(color=COLORS[tgt], width=0.8),
                                     opacity=0.4, showlegend=False), row=row, col=1)
            fig.add_trace(go.Scatter(x=df_ctx["date"], y=roll30,
                                     line=dict(color=COLORS[tgt], width=2.2),
                                     showlegend=False), row=row, col=1)
        apply_layout(fig, title=f"{city} — raw (faint) + 30-day rolling mean", height=600)
        st.plotly_chart(fig, use_container_width=True)

        # Monthly climatology
        st.markdown("<div class='section-title'>Monthly Climatology</div>", unsafe_allow_html=True)
        df_clim = df_nasa.copy()
        df_clim["month"] = df_clim["date"].dt.month
        month_names = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
        clim = df_clim.groupby("month")[TARGETS].agg(["mean","std"]).reset_index()

        fig2 = make_subplots(rows=1, cols=3,
                             subplot_titles=[f"{FULL_NAMES[t]} ({UNITS[t]})" for t in TARGETS])
        for col_idx, tgt in enumerate(TARGETS, 1):
            means  = clim[(tgt, "mean")]
            stds   = clim[(tgt, "std")]
            months = [month_names[m - 1] for m in clim["month"]]
            fig2.add_trace(go.Bar(
                x=months, y=means,
                error_y=dict(type="data", array=stds, visible=True, color="#475569"),
                marker_color=COLORS[tgt], opacity=0.85, showlegend=False,
            ), row=1, col=col_idx)
        apply_layout(fig2, title="Monthly mean ± 1σ (2021–present)", height=320)
        st.plotly_chart(fig2, use_container_width=True)

        # Summary stats
        st.markdown("<div class='section-title'>Summary Statistics</div>", unsafe_allow_html=True)
        stats = df_nasa[TARGETS].describe().T.round(2)
        stats.index = [FULL_NAMES.get(i, i) for i in stats.index]
        st.dataframe(stats, use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# SETUP GUIDE (collapsible)
# ══════════════════════════════════════════════════════════════════════════════
with st.expander("📂 Setup Guide — Multi-city data layout"):
    st.markdown("""
<div class='info-box'>
Place your Kaggle output files in <code>data/</code> next to <code>app.py</code>.
Per-city files are suffixed with the city name (lowercase).
</div>

### Directory layout
```
your-streamlit-app/
├── app.py
└── data/
    ├── logs/
    │   ├── forecast_log_mumbai.jsonl
    │   ├── forecast_log_delhi.jsonl
    │   ├── forecast_log_chennai.jsonl
    │   ├── weight_adjustment_log_mumbai.json
    │   ├── weight_adjustment_log_delhi.json
    │   └── weight_adjustment_log_chennai.json
    ├── cache/
    │   ├── nasa_cache_mumbai.csv
    │   ├── nasa_cache_delhi.csv
    │   └── nasa_cache_chennai.csv
    └── accuracy_metrics.json   ← from training notebook output
```

### Kaggle output structure (from forecasting notebook)
```
/kaggle/output/
├── forecast_log_delhi.jsonl
├── forecast_log_chennai.jsonl
├── forecast_log_mumbai.jsonl
├── weight_adjustment_log_delhi.json
├── weight_adjustment_log_chennai.json
├── weight_adjustment_log_mumbai.json
├── nasa_cache_delhi.csv
├── nasa_cache_chennai.csv
├── nasa_cache_mumbai.csv
└── accuracy_metrics.json      ← from training notebook
```

### accuracy_metrics.json structure
Produced by the training notebook (`training_notebook_delhi_chennai.ipynb`).
Contains train/val/test RMSE, MAE, R², bias, MAPE for every city × mode × target × model.
Copy it from the training notebook's Kaggle output to `data/accuracy_metrics.json`.
""", unsafe_allow_html=True)
